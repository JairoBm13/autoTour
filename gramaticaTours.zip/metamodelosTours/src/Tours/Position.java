/**
 */
package Tours;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Position</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see Tours.ToursPackage#getPosition()
 * @model
 * @generated
 */
public interface Position extends Coordenada {
} // Position
