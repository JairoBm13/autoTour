/**
 */
package Tours;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Rotation</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see Tours.ToursPackage#getRotation()
 * @model
 * @generated
 */
public interface Rotation extends Coordenada {
} // Rotation
